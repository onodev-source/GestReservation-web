
const typeUser = "admin"

const admin = "admin"
const User = {
    typeUser,
    admin
}

export default User